
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome.css')); ?>">
<?php $__env->startSection('estilos'); ?>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if(session()->has('mensajeExitoLibro')): ?>
    <br>
    <div class="alert alert-success">
        <div class="container h6">
            <?php echo e(session()->get('mensajeExitoLibro')); ?>

        </div>
    </div>
    <br>
    <?php endif; ?>

    <?php if(Auth::user()): ?>
        <div class="container text-center">
            <h1>Bienvenido <?php echo e(Auth::user()->name); ?></h1>
        </div>
        <?php if($rol[0]["nombre"] == 'Autor'): ?>
            <div class="container mt-4 mb-5">
                <button type="button" onclick="mostrarForm()" class="btn btn-primary">Proponer contenido</button>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="container text-center">
            <h1>Bienvenido Anonimo</h1>
        </div>
    <?php endif; ?>    

    <div class="container card text-center">
        <div class="card-header">
            <ul class="nav nav-pills card-header-pills">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_null($categoria->catPadre)): ?>
                        <?php if( $categoria->id <= 1): ?>
                            <li class="activo nav-item main-nav-item" id="<?php echo e($categoria->id); ?>">
                                <a class="nav-link" href="#"><?php echo e($categoria->nombre); ?></a>
                            </li>
                        <?php else: ?>
                        <li class="nav-item main-nav-item" id="<?php echo e($categoria->id); ?>">
                            <a class="nav-link" href="#"><?php echo e($categoria->nombre); ?></a>
                        </li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="card-body">
            <div class="card text-center">
                <div class="card-header">
                    <ul class="nav nav-pills card-header-pills">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($categoria->catPadre > 0): ?>
                                <?php if($categoria->catPadre == 1): ?>
                                    <li class="nav-item nav-item-sub" id="<?php echo e($categoria->catPadre); ?>" data-iden2="<?php echo e($categoria->catPadre); ?><?php echo e($categoria->id); ?>">
                                        <a class="nav-link" href="#"><?php echo e($categoria->nombre); ?></a>
                                    </li>
                                <?php else: ?>
                                <li class="nav-item oculto nav-item-sub" id="<?php echo e($categoria->catPadre); ?>" data-iden2="<?php echo e($categoria->catPadre); ?><?php echo e($categoria->id); ?>">
                                    <a class="nav-link" href="#"><?php echo e($categoria->nombre); ?></a>
                                </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="row mt-2">
                        <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($libro->idcategoria <= 6): ?>
                                <div class="col-4 libros" id="<?php echo e($libro->idcategoria); ?>">
                                    <div class="card-header">
                                        Agregado el <?php echo e($libro->fagregado); ?>

                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <?php echo e($libro->nombre); ?>

                                        </h5>
                                        <h6 class="card-subtitle">
                                            <?php echo e($libro->autor); ?>

                                        </h6>
                                        <p class="card-text">
                                            <?php echo e($libro->descripcion); ?>

                                        </p>
                                        <p class="card-text"><small class="text-muted">Ultima actualización: <?php echo e($libro->actualizado); ?></small></p>
                                        <?php if(auth()->check()): ?>
                                            <?php if($rol[0]["nombre"] == 'Autor'): ?>
                                                <form method="POST" action="<?php echo e(route('libros.destroy', $libro->id)); ?>">
                                                    <?php echo csrf_field(); ?>   
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Borrar</button>
                                                </form>
                                                <button type="button" data-toggle="modal" data-libroid="<?php echo e($libro->id); ?>" data-titulo="<?php echo e($libro->nombre); ?>" data-descripcion="<?php echo e($libro->descripcion); ?>" data-target="#edit" class="btn btn-success">Editar</button>
                                            <?php elseif($rol[0]["nombre"] == 'Difusor'): ?>

                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Versiones
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <?php $__currentLoopData = $versiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($version->idlibro == $libro->id): ?>
                                                                <a data-nombreLibro="<?php echo e($version->nombre); ?>" data-descLibro="<?php echo e($version->descripcion); ?>" data-verLibro="<?php echo e($version->version); ?>.0" data-toggle="modal" data-target="#modalVersion" class="dropdown-item" href="#"><?php echo e($version->version); ?>.0</a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <button onclick="Suscribirse()" class="btn btn-primary">
                                                SUBSCRIBIRSE
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="col-4 libros oculto" id="<?php echo e($libro->idcategoria); ?>">
                                    <div class="card-header">
                                        Agregado el <?php echo e($libro->fagregado); ?>

                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <?php echo e($libro->nombre); ?>

                                        </h5>
                                        <h6 class="card-subtitle">
                                            <?php echo e($libro->autor); ?>

                                        </h6>
                                        <p class="card-text">
                                            <?php echo e($libro->descripcion); ?>

                                        </p>
                                        <p class="card-text"><small class="text-muted">Ultima actualización: <?php echo e($libro->actualizado); ?></small></p>
                                        <?php if(auth()->check()): ?>
                                            <?php if($rol[0]["nombre"] == 'Autor'): ?>
                                                <form method="POST" action="<?php echo e(route('libros.destroy', $libro->id)); ?>">
                                                    <?php echo csrf_field(); ?>   
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Borrar</button>
                                                </form>
                                                <button type="button" data-libroid="<?php echo e($libro->id); ?>" data-titulo="<?php echo e($libro->nombre); ?>" data-descripcion="<?php echo e($libro->descripcion); ?>" data-toggle="modal" data-target="#edit" class="btn btn-success">Editar</button>
                                            <?php elseif($rol[0]["nombre"] == 'Difusor'): ?>

                                            <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Versiones
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <?php $__currentLoopData = $versiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($version->idlibro == $libro->id): ?>
                                                                <a data-nombreLibro="<?php echo e($version->nombre); ?>" data-descLibro="<?php echo e($version->descripcion); ?>" data-verLibro="<?php echo e($version->version); ?>.0" data-toggle="modal" data-target="#modalVersion" class="dropdown-item" href="#"><?php echo e($version->version); ?>.0</a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <button onclick="Suscribirse()" class="btn btn-primary">
                                                SUBSCRIBIRSE
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>                  
                </div>
            </div>
        </div>
    </div>

    <?php if(auth()->check()): ?>
        <?php if($rol[0]["nombre"] == 'Difusor'): ?>
            <h2 class="text-center">PENDIENTES</h2>
            <div class="container">
                <div class="row">
                    <div class="col-4 text-center">
                        <?php $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendiente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-header">
                                Agregado el <?php echo e($pendiente->fagregado); ?>

                            </div>
                            <div class="card-body">
                                <h5 class="card-title">
                                    <?php echo e($pendiente->nombre); ?>

                                </h5>
                                <h6 class="card-subtitle">
                                    <?php echo e($pendiente->autor); ?>

                                </h6>
                                <p class="card-text">
                                    <?php echo e($pendiente->descripcion); ?>

                                </p>
                                <p class="card-text"><small class="text-muted">Ultima actualización: <?php echo e($pendiente->actualizado); ?></small></p>
                                <form method="post" action="<?php echo e(route('libros.update', 'none')); ?>" id="aceptarono">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('patch')); ?>

                                    <input type="hidden" id="siOno" name="siOno" value="">
                                    <input type="hidden" id="idLibroAceptar" name="idLibroAceptar" value="<?php echo e($pendiente->id); ?>">
                                    <button type="button" id="aprovado" class="btn btn-primary">Aceptar</button>
                                    <button type="button" id="denegado" class="btn btn-danger">Denegar</button>
                                </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <section class="container-fluid" id="LibroForm">
            <form style="background-color: rgba(54,54,54,0.9); color: #E8E9EB" class="p-4" method="POST" action="<?php echo e(route('libros.store')); ?>">
                <?php echo csrf_field(); ?>
                <button type="button" class="close" aria-label="Close" onclick="mostrarForm()">
                        <span style="color: #E8E9EB;" aria-hidden="true">&times;</span>
                </button>
                <div class="form-group">
                    <label for="nombreL">Nombre del libro: </label>
                    <input class="form-control" type="text" id="nombreL" name="nombreL">
                </div>
                <div class="form-group">
                    <label for="descripcionL">Descripción del libro: </label>
                    <textarea class="form-control" type="text" id="descripcionL" name="descripcionL" rows="4" cols="50"></textarea>
                </div>
                <div class="form-group">
                    <label for="autorL">Nombre del autor: </label>
                    <input class="form-control" type="text" id="autorL" name="autorL">
                </div>
                <div class="form-group">
                    <label for="categoriaL">Categoria del libro: </label>
                    <select class="form-control" name="categoriaL" id="categoriaL">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <option id="<?php echo e($categoria->id); ?>" value="<?php echo e($categoria->id); ?>">
                                    <?php echo e($categoria->nombre); ?>

                                </option>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="fpubliL">Fecha en que publico el libro: </label>
                    <input class="form-control" type="text" id="fpubliL" name="fpubliL">
                </div>
                <button style="background-color: #E8E9EB!important; color: #363636;" type="submit" class="btn btn-primary mb-2">Enviar para aprovacion</button>
                <br>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </form>
    </section>
    
    <!-- Modal -->
    <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="edit">Editar libro</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('libros.update', '1')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('patch')); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="idLibro" id="idLibro" value="">
                            <label for="nombreL">Nombre del libro: </label>
                            <input class="form-control" type="text" id="nombreL" name="nombreL">
                        </div>
                        <div class="form-group">
                            <label for="descripcionL">Descripción del libro: </label>
                            <textarea class="form-control" type="text" id="descripcionL" name="descripcionL" rows="4" cols="50"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    
<!-- Modal -->
<div class="modal fade" id="modalVersion" tabindex="-1" role="dialog" aria-labelledby="modalVersion" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalVersion">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label for="nombreL">Version del libro: </label>
        <input class="form-control" type="text" id="verL" name="verL" readonly="" value="">
        <label for="nombreL">Nombre del libro: </label>
        <input class="form-control" type="text" id="nomL" name="nombreL" readonly="" value="">
        <label for="nombreL">Descripcion del libro: </label>
        <textarea class="form-control" type="text" id="desL" name="descL" readonly="" value="" rows="4" cols="50"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

    <script type="text/javascript" src="<?php echo e(asset('js/funnavitems.js')); ?>">      
    </script>    
    <script type="text/javascript" src="<?php echo e(asset('js/libroStore.js')); ?>"></script>

    <script>
        $('#edit').on('show.bs.modal', function(event){
            var button = $(event.relatedTarget);
            var titulo = button.data('titulo');
            var descripcion = button.data('descripcion');
            var id = button.data('libroid');
            var modal = $(this);
            modal.find('.modal-body #nombreL').val(titulo);
            modal.find('.modal-body #descripcionL').val(descripcion);
            modal.find('.modal-body #idLibro').val(id);
        });

        $('#aprovado').click(function(){
            $('#siOno').val(true);
            $('#aceptarono').submit();
        });

        $('#denegado').click(function(){
            $('#siOno').val(false);
            $('#aceptarono').submit();
        });

        $('#modalVersion').on('show.bs.modal', function(event){
            var a = $(event.relatedTarget);
            var modalNow = $(this);
            var version = a.attr("data-verLibro");
            var titulo = a.attr("data-nombreLibro");
            var descripcion = a.attr("data-descLibro");
            modalNow.find('.modal-body #verL').val(version);
            modalNow.find('.modal-body #nomL').val(titulo);
            modalNow.find('.modal-body #desL').val(descripcion);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/www/NueManCont2/resources/views/welcome.blade.php ENDPATH**/ ?>